# BK Electricals Website - Hostinger Deployment Guide

## 📁 Files Included
- `index.html` - Main homepage
- `work-projects.html` - Projects page
- `.htaccess` - Server configuration for Apache (Hostinger)
- `error.php` - Custom 404 error page
- `robots.txt` - SEO configuration
- `sitemap.xml` - Sitemap for search engines
- All image files (*.jpeg)

## 🚀 How to Upload to Hostinger

### Method 1: Using Hostinger File Manager (Recommended)
1. Login to your Hostinger account
2. Go to **Hosting → Manage**
3. Click on **File Manager**
4. Navigate to `public_html` folder
5. Delete or backup any existing files if needed
6. Click **Upload** button
7. Select and upload all files from this folder
8. Make sure `.htaccess` file is uploaded (it might be hidden on your computer)

### Method 2: Using FTP Client (FileZilla)
1. Get your FTP credentials from Hostinger:
   - Go to **Hosting → Files → FTP Accounts**
   - Note down FTP server, username, and password
2. Open FileZilla or any FTP client
3. Connect using your FTP credentials
4. Navigate to `public_html` folder on the server
5. Upload all files from this folder

### Method 3: Using Hostinger's Git Integration
1. Go to **Hosting → Advanced → Git**
2. Create a new repository
3. Push all files to the repository
4. Deploy to `public_html`

## ⚙️ Important Configuration Steps

### 1. Update Domain in Files
- Edit `sitemap.xml` and replace `yourdomain.com` with your actual domain
- Edit `.htaccess` if you want to force HTTPS (uncomment lines 4-5)

### 2. SSL Certificate
- If you have SSL enabled, uncomment the HTTPS redirect in `.htaccess`
- Go to **Hosting → SSL** in Hostinger to manage SSL certificates

### 3. PHP Configuration
- Hostinger supports PHP by default
- The error.php file will work automatically

### 4. File Permissions
- Most files should have 644 permissions
- Folders should have 755 permissions
- Hostinger usually sets these automatically

## 🔍 Testing Your Website

1. After uploading, visit your domain
2. Test both pages:
   - Homepage: `yourdomain.com`
   - Projects: `yourdomain.com/work-projects`
3. Test 404 error by visiting a non-existent page
4. Check if images are loading properly

## 🛠️ Troubleshooting

### Images Not Loading
- Check if all .jpeg files are uploaded
- Verify file names are correct (case-sensitive)

### Page Not Found Errors
- Make sure `.htaccess` file is uploaded
- Check if mod_rewrite is enabled (it usually is on Hostinger)
- Contact Hostinger support if needed

### White Screen or PHP Errors
- Check PHP version in Hostinger (PHP 7.4+ recommended)
- Check error logs in Hostinger panel

## 📞 Support

### Hostinger Support
- Live Chat: Available 24/7 in Hostinger panel
- Help Center: https://support.hostinger.com

### Website Issues
- Check browser console for JavaScript errors
- Clear browser cache
- Try in incognito/private mode

## ✅ Checklist Before Going Live

- [ ] All files uploaded to public_html
- [ ] Domain name updated in sitemap.xml
- [ ] SSL certificate active (if applicable)
- [ ] Both pages loading correctly
- [ ] All images displaying properly
- [ ] Contact forms tested (if any)
- [ ] Mobile responsive design working
- [ ] Page load speed acceptable

## 📱 Mobile Optimization
The website is already mobile-responsive. Test on different devices to ensure proper display.

## 🎉 Success!
Once everything is uploaded and working, your website should be live at your domain!

---
Last updated: November 2024
Website prepared for Hostinger hosting
